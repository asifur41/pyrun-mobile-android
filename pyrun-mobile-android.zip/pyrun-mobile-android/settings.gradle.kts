pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // If the Chaquopy runtime fails to resolve, add: maven("https://chaquo.com/maven")
    }
}
rootProject.name = "pyrun-mobile-android"
include(":app")
